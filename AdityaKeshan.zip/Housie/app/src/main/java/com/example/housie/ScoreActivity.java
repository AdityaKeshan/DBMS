package com.example.housie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.WindowManager;
import android.widget.CheckBox;

public class ScoreActivity extends AppCompatActivity {
    private CheckBox checkBox,line_one_check,line_two_check,line_three_check;
    private String total,line1,line2,line3;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        checkBox=findViewById(R.id.full_house_check);
        line_one_check=findViewById(R.id.line_one_check);
        line_two_check=findViewById(R.id.line_two_check);
        line_three_check=findViewById(R.id.line_three_check);
        mPreferences= PreferenceManager.getDefaultSharedPreferences(this);
        mEditor=mPreferences.edit();

            Intent intent = getIntent();
            total = intent.getStringExtra("total");
            line1 = intent.getStringExtra("line1");
            line2 = intent.getStringExtra("line2");
            line3 = intent.getStringExtra("line3");

            try {
                if (total.equals("14")) {
                    checkBox.setChecked(true);
                    mEditor.putString("key","full_house");
                    mEditor.apply();
                }}
                catch(NullPointerException ignored)
                {

                }
            try{
               if (line1.equals("5")) {
                    Log.d("LINE","HELLO");
                    line_one_check.setChecked(true);
                    mEditor.putString("key1","line_one_check");
                    mEditor.commit();
                }}
               catch(NullPointerException ignored)
                {

                }
            try {

                 if (line2.equals("4")) {
                    line_two_check.setChecked(true);
                    mEditor.putString("key2","line_two_check");
                    mEditor.commit();
                }}
                 catch(NullPointerException ignored)
                {

                }
                 try{
                     assert line3 != null;
                     if (line3.equals("5")) {
                    line_three_check.setChecked(true);
                    mEditor.putString("key3","line_three_check");
                    mEditor.commit();
                }

                }
                catch (NullPointerException ignored)
                {

                }




    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("STARTT","HELLO");
        if(mPreferences.getString("key","").contentEquals("full_house"))
        {
            checkBox.setChecked(true);
        }
        if(mPreferences.getString("key1","").contentEquals("line_one_check"))
        {
            line_one_check.setChecked(true);
        }
        if(mPreferences.getString("key2","").contentEquals("line_two_check"))
        {
            line_two_check.setChecked(true);
        }
        if(mPreferences.getString("key3","").contentEquals("line_three_check"))
        {
            line_three_check.setChecked(true);
        }
    }


}