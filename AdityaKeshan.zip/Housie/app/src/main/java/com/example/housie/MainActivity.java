package com.example.housie;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.text.Html;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

import static java.lang.Math.random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, GestureDetector.OnGestureListener {
    private Button[][] buttons = new Button[3][9];
    private Button refresh;
    private Button generator;
    ProgressBar progressBar;
    private TextView generatedNumber;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;
    ArrayList<String> ac;
    int line1=0,line2=0,line3=0;
    private float x1, x2, y1, y2;
    private static int MIN_DISTANCE = 150;
    private GestureDetector gestureDetector;
    private CheckBox fullhousecheck;
    private RandomAdapter adapter;
    RecyclerView recyclerView;
    ArrayList<String> source;
    RecyclerView.LayoutManager RecyclerViewLayoutManager;
    LinearLayoutManager HorizontalLayout;
    View ChildView;
    ArrayList<String> a;
    private Handler mHandler = new Handler();
    ArrayList<Integer> intTicket = new ArrayList<>();
    ArrayList<String> Ticket = new ArrayList<>();

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                x1=event.getX();
                y1=event.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2=event.getX();
                y2=event.getY();

                float valueX=x2-x1;
                float valueY=y2-y1;
                if(Math.abs(valueY)>MIN_DISTANCE)
                {
                    if(y2>y1)
                    {
                        //top to bottom
                    }
                    else
                    {
                        /*Intent intent=new Intent(MainActivity.this,ScoreActivity.class);
                        startActivity(intent);*/
                    }
                }
        }
        return super.onTouchEvent(event);
    }
    @Override
    protected void onPause() {

        super.onPause();
        SharedPreferences settings = getSharedPreferences("Data",0);
        SharedPreferences.Editor editor = settings.edit();
        editor.clear();
        editor.apply();
        mHandler.removeCallbacksAndMessages(null);

    }
    public String black(String e)
    {
        if(Integer.parseInt(e)<10)
        {
            e="0"+e;
        }
        String z=" <font color=#FFFFFF>"+e+"</font> ";
        return z;
    }
    public String green(String e)
    {
        if(Integer.parseInt(e)<10)
        {
            e="0"+e;
        }
        String z=" <font color=#FFC20E>"+e+"</font> ";
        return z;
    }
    TextView board;
    TextToSpeech t1;
    ArrayList<String> ab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar = findViewById(R.id.progress_bar);
        getWindow().setNavigationBarColor(getResources().getColor(R.color.colorBack));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION,WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        ab=new ArrayList<>();
        this.gestureDetector = new GestureDetector(MainActivity.this, this);
        fullhousecheck = findViewById(R.id.full_house_check);
        ac = new ArrayList<>();
        t1=new TextToSpeech(getApplicationContext(), status -> {
            if(status != TextToSpeech.ERROR) {
                t1.setLanguage(Locale.UK);
            }
        });
        source = new ArrayList<>();
        a = new ArrayList<>();
        generatedNumber = findViewById(R.id.tv_randomNumber);
        adapter = new RandomAdapter(getApplicationContext(), ab);
        board = findViewById(R.id.textView);
        recyclerView = findViewById(R.id.recyclerview);
        RecyclerViewLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(RecyclerViewLayoutManager);
        recyclerView.setAdapter(adapter);
        String fin = "";
        for (int i = 0; i <= 89; i++) {
            source.add(black(String.valueOf(i + 1)));
        }
        textset();


        generateTicket();
        mToastRunnable.run();
    }

    public void generateTicket(){
        for (int k = 0; k < 9; k++) {
            if (k % 2 == 0) {
                for (int m = 0; m < 2; m++) {
                    int num = generateTicketNumber(k);
                    intTicket.add(num);
                }
            }
            else{
                for (int m = 0; m < 1; m++) {
                    int  num = generateTicketNumber(k);
                    intTicket.add(num);
                }
            }
        }
        Collections.sort(intTicket);


        for (int i = 0; i < intTicket.size(); i++) {
            Ticket.add("" + intTicket.get(i).toString());
        }


        int x = 0;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 3; j++) {
                Log.d("IN", "X");
                String button = "button" + j + i;
                int resID = getResources().getIdentifier(button, "id", getPackageName());
                buttons[j][i] = findViewById(resID);
                //buttons[i][j].setOnClickListener(this);
                if ((i + j) % 2 == 0) {
                    buttons[j][i].setText(Ticket.get(x));
                    x++;

                }

            }
        }
    }

    public int generateTicketNumber(int k){
        int num = ((int) (random() * ((10 *( k + 1)) - (10 * k + 1)) + 1) + (10 * k + 1));
        if(!intTicket.contains(num)){}
        else{num = generateTicketNumber(k);}
        return num;

    }

    private Runnable mToastRunnable = new Runnable() {
        @Override
        public void run() {
            generateNumber();
            adapter.notifyDataSetChanged();
            textset();
            final int tp = 100;

            Thread process = new Thread() {
                public void run() {
                    int pd = 0;
                    while (pd < tp) {
                        try {
                            sleep(50);
                            pd++;
                            progressBar.setProgress(pd);

                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                    }
                }
            };
            process.start();
            mHandler.postDelayed(this, 5000);
        }
    };
    private void textset()
    {
        StringBuilder sb = new StringBuilder();
        int f=0;
        for (String s : source)
        {
            if(f%5==0){
                sb.append("<br>");
            }
            f++;
            sb.append(s);
            sb.append(" ");
        }
        board.setText(Html.fromHtml(String.valueOf(sb)));
    }
    private String generate()
    {
        String gn = "" + ((int) (Math.random() * ((90 - 1) + 1)) + 1);
        if(!ac.contains(gn))
        {

            ac.add(gn);
            return gn;


        }
        else
        {
            return generate();
        }
    }
    private void generateNumber(){
        String lastNumber = generatedNumber.getText().toString();
        String gn = generate();
        if (!ab.contains(gn)) {
            generatedNumber.setText(gn);
            t1.speak(gn, TextToSpeech.QUEUE_FLUSH, null);
            ArrayList<String> k=new ArrayList<>();
            k.add(lastNumber);
            k.addAll(ab);
            ab.clear();
            ab.addAll(k);
            int g=Integer.parseInt(gn);
            source.remove(g-1);
            source.add(g-1,green(String.valueOf(g)));
        }
        else{
            if (ab.size()!=89){generateNumber();}
        }
    }


    @Override
    public void onClick(View view) {
        Log.i("The tag:", view.getTag().toString());
        String k = view.getTag().toString();
        int x=Integer.parseInt(k);
        Log.d("BUTTON",""+x);
        if(x>=20)
            line3++;
        else if(x>=10)
            line2++;
        else
            line1++;
        Log.d("LINE1","="+line1);
        Log.d("LINE2","="+line2);
        Log.d("LINE3","="+line3);
        if (ac == null) {
            view.setBackgroundColor(Color.parseColor("#FFFF0E3E"));
            ac.add(k);
        } else {
            if (!ac.contains(k)) {

                view.setBackgroundColor(Color.parseColor("#FFFF0E3E"));
                ac.add(k);
            }
        }

        if (ac.size() == 14) {
            line1=line2=line3=0;
            Intent i = new Intent(MainActivity.this, ScoreActivity.class);
            i.putExtra("total", "14");
            startActivity(i);

        }
        if(line1==5)
        {
            line1=0;
            Intent i1 = new Intent(MainActivity.this, ScoreActivity.class);
            i1.putExtra("line1", "5");
            startActivity(i1);
        }
        if(line2==4)
        {
            line2=0;
            Intent i2 = new Intent(MainActivity.this, ScoreActivity.class);
            i2.putExtra("line2", "4");
            startActivity(i2);
        }
        if(line3==5)
        {
            line3=0;
            Intent i3 = new Intent(MainActivity.this, ScoreActivity.class);
            i3.putExtra("line3", "5");
            startActivity(i3);
        }
    }



    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }


}