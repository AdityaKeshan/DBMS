package com.example.housie;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PrizeCalculation extends AppCompatActivity {

    Button btnCalculate;
    TextView tvEarlyFive, tvTopLine, tvMiddleLine, tvBottomLine, tvFourCorners, tvGoldenLaddu, tvFullHouse;
    EditText etTotalTickets, etPricePerTicket, etTotalHouseFulls;
    int earlyFivePrice;
    int topLinePrice;
    int middleLinePrice;
    int bottomLinePrice;
    int fourCornerPrice;
    int fullHousePrice;
    int goldenLadduPrice;
    int pricePerTicket;
    int totalTicketNumber;
    int totalHouseFulls;
    int remained;
    String price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prize_calculation);

        btnCalculate = findViewById(R.id.btn_calculate);

        etPricePerTicket = findViewById(R.id.et_price_per_ticket);
        etTotalTickets = findViewById(R.id.et_number_of_tickets);
        etTotalHouseFulls = findViewById(R.id.et_number_of_housefulls);

        tvBottomLine  = findViewById(R.id.tv_bottom_line_price);
        tvEarlyFive = findViewById(R.id.tv_early_five_price);
        tvFourCorners = findViewById(R.id.tv_four_corners_price);
        tvFullHouse = findViewById(R.id.tv_full_house_price);
        tvGoldenLaddu = findViewById(R.id.tv_golden_laddu_price);
        tvMiddleLine = findViewById(R.id.tv_middle_line_price);
        tvTopLine = findViewById(R.id.tv_top_line_price);
        remained = 0;

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!etPricePerTicket.getText().toString().equals("")) {
                    pricePerTicket = Integer.parseInt(etPricePerTicket.getText().toString());
                }
                else {
                    etPricePerTicket.setError("Please Enter Values");
                    etPricePerTicket.requestFocus();
                    return;
                }

                if (!etTotalTickets.getText().toString().equals("")) {
                    totalTicketNumber = Integer.parseInt(etTotalTickets.getText().toString());
                } else {
                    etTotalTickets.setError("Please Enter Values");
                    etTotalTickets.requestFocus();
                    return;
                }

                if (!etTotalHouseFulls.getText().toString().equals("")) {
                    totalHouseFulls = Integer.parseInt(etTotalHouseFulls.getText().toString());
                } else {
                    etTotalHouseFulls.setError("Please Enter Values");
                    etTotalHouseFulls.requestFocus();
                    return;
                }
                etTotalHouseFulls.setEnabled(false);
                etTotalTickets.setEnabled(false);
                etPricePerTicket.setEnabled(false);


                calculatePrizes();
            }
        });




    }


    private void calculatePrizes() {


        int totalAmount = totalTicketNumber * pricePerTicket;

        goldenLadduPrice = totalAmount / 6;
        price = "" + adjustPrice(goldenLadduPrice);
        tvGoldenLaddu.setText(price);

        fourCornerPrice = totalAmount / 8;
        price = "" + adjustPrice(fourCornerPrice);
        tvFourCorners.setText(price);

        topLinePrice = totalAmount / 8;
        price = "" + adjustPrice(topLinePrice);
        tvTopLine.setText(price);

        middleLinePrice = totalAmount / 8;
        price = "" + adjustPrice(middleLinePrice);
        tvMiddleLine.setText(price);

        bottomLinePrice = totalAmount / 8;
        price = "" + adjustPrice(bottomLinePrice);
        tvBottomLine.setText(price);

        earlyFivePrice = totalAmount / 12;
        price = "" + adjustPrice(earlyFivePrice);
        tvEarlyFive.setText(price);

        if (remained != 0) {
            fullHousePrice = ((2 * totalAmount / 8) + remained) / totalHouseFulls;
        } else {
            fullHousePrice = (2 * totalAmount / 8) / totalHouseFulls;
        }
        price = "" + adjustPrice(fullHousePrice);
        tvFullHouse.setText(price);

        btnCalculate.setEnabled(false);


    }

    private int adjustPrice(int price) {
        if (price % 10 != 0) {
            price -= (price % 10);
            remained += (price % 10);
        }

        return price;
    }

    /**
     * Dispatch onPause() to fragments.
     */
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences settings = getSharedPreferences("State", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("State", "paused");
        editor.putString("num_tickets", String.valueOf(totalTicketNumber));
        editor.putString("price_per_ticket", String.valueOf(pricePerTicket));
        editor.putString("num_housefulls", String.valueOf(totalHouseFulls));
        editor.apply();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SharedPreferences settings = getSharedPreferences("State", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.clear();
        editor.apply();

    }

    /**
     * Dispatch onResume() to fragments.  Note that for better inter-operation
     * with older versions of the platform, at the point of this call the
     * fragments attached to the activity are <em>not</em> resumed.
     */
    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences settings = getSharedPreferences("State", 0);
        String state = settings.getString("State", null);
        if (state != null) {
            if (state.equals("paused")) {
                settings.getString("num_tickets", "1");
                settings.getString("price_per_ticket", "1");
                settings.getString("num_housefulls", "1");

                if (!etPricePerTicket.getText().toString().equals("")) {
                    pricePerTicket = Integer.parseInt(etPricePerTicket.getText().toString());
                } else {
                    etPricePerTicket.setError("Please Enter Values");
                    etPricePerTicket.requestFocus();
                    return;
                }

                if (!etTotalTickets.getText().toString().equals("")) {
                    totalTicketNumber = Integer.parseInt(etTotalTickets.getText().toString());
                } else {
                    etTotalTickets.setError("Please Enter Values");
                    etTotalTickets.requestFocus();
                    return;
                }

                if (!etTotalHouseFulls.getText().toString().equals("")) {
                    totalHouseFulls = Integer.parseInt(etTotalHouseFulls.getText().toString());
                } else {
                    etTotalHouseFulls.setError("Please Enter Values");
                    etTotalHouseFulls.requestFocus();
                    return;
                }
                etTotalHouseFulls.setEnabled(false);
                etTotalTickets.setEnabled(false);
                etPricePerTicket.setEnabled(false);


                calculatePrizes();
            }
        }


    }

}


