package com.example.housie;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class RandomAdapter extends RecyclerView.Adapter<RandomAdapter.ViewHolder> {

    @NonNull
    public ArrayList<String> numbers;
    Context con;
    public RandomAdapter(Context context,ArrayList<String> s)
    {
        con=context;
        numbers=s;
    }
    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView code;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            code=itemView.findViewById(R.id.tv_randomNumber);
//            itemView.setTag(this);
//            itemView.setOnClickListener(onItemClickListener);

        }
    }

    @NonNull
    @Override
    public RandomAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.random_generated_number, parent ,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RandomAdapter.ViewHolder holder, final int position) {
        holder.itemView.setTag(numbers.get(position));
        holder.code.setText(numbers.get(position));

    }

    @Override
    public int getItemCount() {

        if(numbers!=null){return numbers.size();}
        else{
            return 0;
        }
    }
}