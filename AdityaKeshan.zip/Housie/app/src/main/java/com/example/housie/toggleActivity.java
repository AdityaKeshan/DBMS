package com.example.housie;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class toggleActivity extends AppCompatActivity {
    private Button realButton,virtualButton,soundButton;
    private SharedPreferences mPreferences,soundPrefernces;
    private SharedPreferences.Editor mEditor,editor2;
    public void starter(View v)
    {
        Intent I=new Intent(toggleActivity.this,RealTime.class);
        startActivity(I);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toggle);
        soundPrefernces= PreferenceManager.getDefaultSharedPreferences(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        realButton=findViewById(R.id.button_real);
        soundButton=findViewById(R.id.button_sound);
        /*virtualButton=findViewById(R.id.button_virtual);
        virtualButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(toggleActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });*/
        soundButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(soundButton.getBackground().getConstantState()==getResources().getDrawable(R.drawable.ic_baseline_volume_up_24).getConstantState()) {
                    soundButton.setBackgroundResource(R.drawable.ic_baseline_volume_off_24);
                    AudioManager audioManager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
                    assert audioManager != null;
                    audioManager.setStreamMute(AudioManager.STREAM_MUSIC,true);
                    audioManager.setStreamMute(AudioManager.STREAM_SYSTEM,true);
                    editor2=soundPrefernces.edit();
                    editor2.putString("sound","off");
                }
                else
                {
                    soundButton.setBackgroundResource(R.drawable.ic_baseline_volume_up_24);
                    AudioManager audioManager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
                    assert audioManager != null;
                    audioManager.setStreamMute(AudioManager.STREAM_MUSIC,false);
                    audioManager.setStreamMute(AudioManager.STREAM_SYSTEM,false);
                    editor2=soundPrefernces.edit();
                    editor2.putString("sound","on");
                }
                editor2.apply();
            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();
        soundPrefernces= PreferenceManager.getDefaultSharedPreferences(this);
        if(soundPrefernces.getString("sound","").contentEquals("on"))
        {
            soundButton.setBackgroundResource(R.drawable.ic_baseline_volume_up_24);
            Button soundButton=findViewById(R.id.button_sound);
            AudioManager audioManager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
            audioManager.setStreamMute(AudioManager.STREAM_MUSIC,false);
            audioManager.setStreamMute(AudioManager.STREAM_SYSTEM,false);
        }
        else if(soundPrefernces.getString("sound","").contentEquals("off"))
        {
            soundButton.setBackgroundResource(R.drawable.ic_baseline_volume_off_24);
            Button soundButton=findViewById(R.id.button_sound);
            AudioManager audioManager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
            audioManager.setStreamMute(AudioManager.STREAM_MUSIC,true);
            audioManager.setStreamMute(AudioManager.STREAM_SYSTEM,true);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mPreferences= PreferenceManager.getDefaultSharedPreferences(this);
        mEditor=mPreferences.edit();
        mEditor.clear();
        mEditor.apply();
    }
}