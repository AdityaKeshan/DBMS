package com.example.housie;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.warkiz.widget.IndicatorSeekBar;
import com.warkiz.widget.OnSeekChangeListener;
import com.warkiz.widget.SeekParams;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;

public class RealTime extends AppCompatActivity implements View.OnClickListener {

    public static final Integer RecordAudioRequestCode = 1;
    final Intent speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    int number_delay = 7000,number_delay_temp = 7000;
    TextView[][] textView = new TextView[10][10];
    ArrayList<String> source;
    TextView prev, curr;
    TextView board;
    TextToSpeech t1;
    SharedPreferences soundPrefernces;
    ProgressBar progressBar;
    MediaPlayer mp = new MediaPlayer();
    FloatingActionButton fabMain, fabMic, fabCalc, fabCtrl, fabSW;
    Float translationX = 100f;
    Boolean isMenuOpen;
    OvershootInterpolator interpolator = new OvershootInterpolator();
    Boolean isPlaying;
    ArrayList<String> ab;
    private SpeechRecognizer speechRecognizer;
    private Handler mHandler = new Handler();
    IndicatorSeekBar indicatorSeekBar;
    int ticketsNum;
    int pricePT;
    int fullHouseNum;
    int earlyFivePrice;
    int topLinePrice;
    int middleLinePrice;
    int bottomLinePrice;
    int fourCornerPrice;
    int fullHousePrice;
    int goldenLadduPrice;
    int remained;
    String price;
    TextView tvEarlyFive, tvTopLine, tvMiddleLine, tvBottomLine, tvFourCorners, tvGoldenLaddu, tvFullHouse;
    CardView cv_board;
    TextView tv_prev1, tv_prev2, tv_prev3;
    LinearLayout ll_prev;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_real_time);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        prev = findViewById(R.id.prev);
        curr = findViewById(R.id.curr);
        indicatorSeekBar = findViewById(R.id.isb);
        indicatorSeekBar.setVisibility(View.GONE);
        tv_prev1 = findViewById(R.id.tv_prev1);
        tv_prev2 = findViewById(R.id.tv_prev2);
        tv_prev3 = findViewById(R.id.tv_prev3);
        cv_board = findViewById(R.id.cv_tv);
        ll_prev = findViewById(R.id.ll_prev);
        tv_prev1.setOnClickListener(v -> {
            Log.i("Board", "Its Here");
            showBoard.run();
        });
        tv_prev2.setOnClickListener(v -> {
            Log.i("Board", "Its Here");
            showBoard.run();
        });
        tv_prev3.setOnClickListener(v -> {
            Log.i("Board", "Its Here");
            showBoard.run();
        });


        prev.setVisibility(View.GONE);

        cv_board.setVisibility(View.INVISIBLE);


        for (int i = 1; i <= 90; i++) {
            int tenth = i / 10;
            int unit = i % 10;
            String tv = "tv" + tenth + unit;
            int resID = getResources().getIdentifier(tv, "id", getPackageName());
            textView[tenth][unit] = findViewById(resID);
            textView[tenth][unit].setTextSize(20);
            textView[tenth][unit].setTextColor(getResources().getColor(R.color.white));
            textView[tenth][unit].setBackground(ContextCompat.getDrawable(this,R.drawable.bg_circle));

        }

        indicatorSeekBar.setOnSeekChangeListener(new OnSeekChangeListener() {
            @Override
            public void onSeeking(SeekParams seekParams) {
                number_delay_temp = seekParams.progress * 1000;
            }

            @Override
            public void onStartTrackingTouch(IndicatorSeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(IndicatorSeekBar seekBar) {
                indicatorSeekBar.setVisibility(View.INVISIBLE);

            }
        });



        progressBar = findViewById(R.id.progress_bar);

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);

        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        isMenuOpen = false;
        isPlaying = true;


        fabInit();


        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle bundle) {
                mp.stop();

            }

            @Override
            public void onBeginningOfSpeech() {
                mp.stop();
            }

            @Override
            public void onRmsChanged(float v) {

            }

            @Override
            public void onBufferReceived(byte[] bytes) {

            }

            @Override
            public void onEndOfSpeech() {

            }

            @Override
            public void onError(int i) {

            }

            @Override
            public void onResults(Bundle bundle) {
                fabMic.setImageResource(R.drawable.ic_microphone);
                ArrayList<String> data = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                assert data != null;
                String f = data.get(0);
                if (f.equalsIgnoreCase("stop") || f.equalsIgnoreCase("pause")) {
                    isPlaying = false;
                    try {
                        mHandler.removeCallbacks(mToastRunnable);
                        fabCtrl.setImageResource(R.drawable.ic_play);
                    } catch (Exception e) {
                        Log.e("The error", String.valueOf(e.getMessage()));
                    }
                } else if (f.equalsIgnoreCase("start") || f.equalsIgnoreCase("play")) {
                    if (!isPlaying) {
                        mHandler.postDelayed(mToastRunnable, number_delay);//Start again
                        fabCtrl.setImageResource(R.drawable.ic_stop);
                        isPlaying = true;
                    }
                }
            }

            @Override
            public void onPartialResults(Bundle bundle) {

            }

            @Override
            public void onEvent(int i, Bundle bundle) {

            }
        });

        t1 = new TextToSpeech(getApplicationContext(), status -> {
            if (status != TextToSpeech.ERROR) {
                t1.setLanguage(Locale.UK);
            }
        });
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            checkPermission();
        }
        source = new ArrayList<>();

        board = findViewById(R.id.textView);
        ab = new ArrayList<>();
        /*for (int i = 1; i <= 90; i++) {
            source.add(black(String.valueOf(i)));
        }*/
        mToastRunnable.run();
    }


    @Override
    public void onPause() {

        super.onPause();
        mp.stop();
        mHandler.removeCallbacksAndMessages(null);
        SharedPreferences settings = getSharedPreferences("Data", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.clear();
        editor.putStringSet("Board", new HashSet<>(source));
        editor.putString("Prev", prev.getText().toString());
        editor.putString("Curr", curr.getText().toString());
        editor.apply();
    }

    @Override
    public void onBackPressed() {
        mp.stop();
        SharedPreferences settings = getSharedPreferences("Data", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.apply();
        editor.clear();
        Intent I = new Intent(RealTime.this, toggleActivity.class);
        startActivity(I);
        finish();
    }


    @Override
    protected void onStart() {
        super.onStart();
        soundPrefernces = PreferenceManager.getDefaultSharedPreferences(this);
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        assert audioManager != null;
        if (soundPrefernces.getString("sound", "").contentEquals("on")) {


            audioManager.setStreamMute(AudioManager.STREAM_MUSIC, false);
            audioManager.setStreamMute(AudioManager.STREAM_SYSTEM, false);
        } else if (soundPrefernces.getString("sound", "").contentEquals("off")) {

            audioManager.setStreamMute(AudioManager.STREAM_MUSIC, true);
            audioManager.setStreamMute(AudioManager.STREAM_SYSTEM, true);
        }
    }

    public void menuOpen() {

        isMenuOpen = !isMenuOpen;
        fabMain.animate().setInterpolator(interpolator).rotation(180f).setDuration(300).start();
        fabCalc.animate().translationX(0f).alpha(1f).setInterpolator(interpolator).setDuration(500).start();
        fabMic.animate().translationX(0f).alpha(1f).setInterpolator(interpolator).setDuration(500).start();
        fabCtrl.animate().translationX(0f).alpha(1f).setInterpolator(interpolator).setDuration(500).start();
        fabSW.animate().translationX(0f).alpha(1f).setInterpolator(interpolator).setDuration(500).start();
    }

    public void menuClose() {

        isMenuOpen = !isMenuOpen;
        fabMain.animate().setInterpolator(interpolator).rotation(0f).setDuration(500).start();
        fabCalc.animate().translationX(translationX).alpha(0f).setInterpolator(interpolator).setDuration(500).start();
        fabMic.animate().translationX(translationX).alpha(0f).setInterpolator(interpolator).setDuration(500).start();
        fabCtrl.animate().translationX(translationX).alpha(0f).setInterpolator(interpolator).setDuration(500).start();
        fabSW.animate().translationX(translationX).alpha(0f).setInterpolator(interpolator).setDuration(500).start();

    }

    public void fabInit() {
        fabMain = findViewById(R.id.fabMain);
        fabMic = findViewById(R.id.fabMic);
        fabCalc = findViewById(R.id.fabCalc);
        fabCtrl = findViewById(R.id.fabCtrl);
        fabSW = findViewById(R.id.fabSW);


        fabMic.setAlpha(0f);
        fabCtrl.setAlpha(0f);
        fabCalc.setAlpha(0f);
        fabSW.setAlpha(0f);

        fabMic.setTranslationX(translationX);
        fabCtrl.setTranslationX(translationX);
        fabCalc.setTranslationX(translationX);
        fabSW.setTranslationX(translationX);

        fabMain.setOnClickListener(this);
        fabCalc.setOnClickListener(this);
        fabMic.setOnClickListener(this);
        fabSW.setOnClickListener(this);
        fabCtrl.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.fabMain:
                Log.i("FAB", "In the MAin");
                if (isMenuOpen) { menuClose(); }
                else { menuOpen(); }
                break;

            case R.id.fabCalc:
                mHandler.removeCallbacks(mToastRunnable);
                calculatePrices();

                /*startActivity(new Intent(this, PrizeCalculation.class));*/
                break;

            case R.id.fabCtrl:
                if (isPlaying) {
                    mHandler.removeCallbacks(mToastRunnable);//Stop
                    fabCtrl.setImageResource(R.drawable.ic_play);
                    isPlaying = false;
                } else {
                    mHandler.postDelayed(mToastRunnable, number_delay);//Start again
                    fabCtrl.setImageResource(R.drawable.ic_stop);
                    isPlaying = true;
                }
                break;

            case R.id.fabMic:
                fabMic.setImageResource(R.drawable.ic_microphone_off);
                speechRecognizer.startListening(speechRecognizerIntent);
                break;

            case R.id.fabSW:
                indicatorSeekBar.setVisibility(View.VISIBLE);
                break;

            case R.id.tv_prev1:
            case R.id.tv_prev2:
            case R.id.tv_prev3:
                showBoard.run();
                break;

            default:
                Log.i("Switch", "ID not Found");
                break;


        }
    }

    private void calculatePrices() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = (this).getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.activity_prize_calculation_input, null);
        dialogBuilder.setView(dialogView);
        EditText etTickets = dialogView.findViewById(R.id.et_number_of_tickets);
        EditText etPrice = dialogView.findViewById(R.id.et_price_per_ticket);
        EditText etfullHouse = dialogView.findViewById(R.id.et_number_of_housefulls);

        dialogBuilder.setPositiveButton("Calculate", (dialog, which) -> {

            if (!((etPrice.getText().toString().equals("")) || (etTickets.getText().toString().equals("")) || (etfullHouse.getText().toString().equals("")))) {
                pricePT = Integer.parseInt(etPrice.getText().toString());
                ticketsNum = Integer.parseInt(etTickets.getText().toString());
                fullHouseNum = Integer.parseInt(etfullHouse.getText().toString());
            } else {
                Toast.makeText(this, "Please Provide all Inputs", Toast.LENGTH_LONG).show();
                return;
            }


            AlertDialog.Builder dialogBuilder2 = new AlertDialog.Builder(this);
            LayoutInflater inflater2 = (this).getLayoutInflater();
            View dialogView2 = inflater2.inflate(R.layout.activity_prize_calculation_output, null);


            tvBottomLine = dialogView2.findViewById(R.id.tv_bottom_line_price);
            tvEarlyFive = dialogView2.findViewById(R.id.tv_early_five_price);
            tvFourCorners = dialogView2.findViewById(R.id.tv_four_corners_price);
            tvFullHouse = dialogView2.findViewById(R.id.tv_full_house_price);
            tvGoldenLaddu = dialogView2.findViewById(R.id.tv_golden_laddu_price);
            tvMiddleLine = dialogView2.findViewById(R.id.tv_middle_line_price);
            tvTopLine = dialogView2.findViewById(R.id.tv_top_line_price);


            calculatePrizes(pricePT, ticketsNum, fullHousePrice);
            dialogBuilder2.setView(dialogView2);
            dialogBuilder2.setPositiveButton("Exit", (dialog1, which1) -> {
                mToastRunnable.run();
                return;
            });
            dialogBuilder2.create().show();

        });

        dialogBuilder.create().show();
    }

    private void calculatePrizes(int pricePerTicket, int totalTicketNumber, int totalHouseFulls) {


        int totalAmount = totalTicketNumber * pricePerTicket;

        goldenLadduPrice = totalAmount / 6;
        price = "" + adjustPrice(goldenLadduPrice);
        tvGoldenLaddu.setText(price);

        fourCornerPrice = totalAmount / 8;
        price = "" + adjustPrice(fourCornerPrice);
        tvFourCorners.setText(price);

        topLinePrice = totalAmount / 8;
        price = "" + adjustPrice(topLinePrice);
        tvTopLine.setText(price);

        middleLinePrice = totalAmount / 8;
        price = "" + adjustPrice(middleLinePrice);
        tvMiddleLine.setText(price);

        bottomLinePrice = totalAmount / 8;
        price = "" + adjustPrice(bottomLinePrice);
        tvBottomLine.setText(price);

        earlyFivePrice = totalAmount / 12;
        price = "" + adjustPrice(earlyFivePrice);
        tvEarlyFive.setText(price);

        if (remained != 0 && totalHouseFulls != 0) {
            fullHousePrice = ((2 * totalAmount / 8) + remained) / totalHouseFulls;
        } else {
            fullHousePrice = (2 * totalAmount / 8);
        }
        price = "" + adjustPrice(fullHousePrice);
        tvFullHouse.setText(price);


    }

    private int adjustPrice(int price) {
        if (price % 10 != 0) {
            price -= (price % 10);
            remained += (price % 10);
        }

        return price;
    }

    private Runnable showBoard = new Runnable() {
        @Override
        public void run() {


            Log.i("Board", "Its Here2");
            tv_prev1.setVisibility(View.GONE);
            tv_prev2.setVisibility(View.GONE);
            tv_prev3.setVisibility(View.GONE);
            cv_board.setVisibility(View.VISIBLE);
            prev.setVisibility(View.VISIBLE);
            Thread stop = new Thread() {
                @Override
                public void run() {
                    super.run();
                    try {

                            Log.i("Board", "Its Here3");
                        cv_board.setVisibility(View.GONE);
                        prev.setVisibility(View.GONE);
                        tv_prev1.setVisibility(View.VISIBLE);
                        tv_prev2.setVisibility(View.VISIBLE);
                        tv_prev3.setVisibility(View.VISIBLE);

                        sleep(7000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            };
            stop.start();
            Log.i("Board", "Its Here4");

            /*mHandler.postDelayed(this,7000);*/
        }

    };


    private Runnable mToastRunnable = new Runnable() {
        @Override
        public void run() {
            fabCtrl.setImageResource(R.drawable.ic_stop);
            String gn = generate();
            String z = curr.getText().toString();
            String prev1 = curr.getText().toString();
            String prev2 = tv_prev1.getText().toString();
            String prev3 = tv_prev2.getText().toString();
            prev.setText(z);
            curr.setText(gn);
            tv_prev1.setText(prev1);
            tv_prev2.setText(prev2);
            tv_prev3.setText(prev3);


            String audio = "s" + gn;
            int path = getApplicationContext().getResources().getIdentifier(audio, "raw",
                    getApplicationContext().getPackageName());


            mp = MediaPlayer.create(RealTime.this, path);
            try {

                mp.setOnPreparedListener(mp -> {
                    mp.start();
                    Log.i("Media Player", "Audio Started");
                });
                mp.setOnCompletionListener(mp -> {
                    mp.release();
                    Log.i("MediaPlayer", "Player Released");
                });


                Log.i("audio", "audio = " + audio + ", Path = " + path);
            } catch (Exception e) {
                e.printStackTrace();
            }


            int g = Integer.parseInt(gn);
            /*source.remove(g-1);
            source.add(g-1, green(String.valueOf(g)));
            textset();*/

            textView[g/10][g%10].setTextColor(getResources().getColor(R.color.colorBack));
            textView[g/10][g%10].setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.bg_circle_white));

            final int tp = 100;

            Thread process = new Thread() {
                public void run() {
                    int pd = 0;
                    while (pd < tp) {
                        try {
                            sleep(number_delay/100);
                            pd++;
                            progressBar.setProgress(pd);

                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                    }
                }
            };

            process.start();
            number_delay = number_delay_temp;
            mHandler.postDelayed(this, number_delay);

        }
    };

   /* public String black(String e) {
        if (Integer.parseInt(e) < 10) {
            e = "0" + e;
        }
        return " <font color=#FFFFFF>" + e + "</font> ";
    }

    public String green(String e) {
        if (Integer.parseInt(e) < 10) {
            e = "0" + e;
        }

        return " <font color=#FFC20E>" + e + "</font> ";
    }*/

    private void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, RecordAudioRequestCode);
        }
    }

    private String generate() {
        String gn = "" + ((int) (Math.random() * ((90 - 1) + 1)) + 1);
        if (!ab.contains(gn)) {
            ab.add(gn);
            return gn;
        } else {
            return generate();
        }
    }

    /*private void textset() {
        StringBuilder sb = new StringBuilder();
        for (String s : source) {
            int num=0;
            String string = String.valueOf(Html.fromHtml(String.valueOf(s)));
            for(int i=0;i<string.length()-1;i++){
                num=(num*10)+Integer.parseInt(String.valueOf(string.charAt(i)));
            }
            sb.append(s);
            if(num%10==0){
                sb.append("<br>");
            }
            else {
                sb.append("\t");
            }


        }
        board.setText(Html.fromHtml(String.valueOf(sb)));
    }*/
}